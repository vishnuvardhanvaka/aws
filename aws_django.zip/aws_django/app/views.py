from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.
def home(request):
    print('hello vishnu request has been taken !')
    return HttpResponse('hello vishnu this is a http response ')